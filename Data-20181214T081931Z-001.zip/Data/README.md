
If you want to run these repackaged apps detection tools, you should download the apk files first.

you can run the file python get_repackaging_pairs.py to download the repackaged app pairs.

The apk list and the apk pairs data can be found in the directory Data.
