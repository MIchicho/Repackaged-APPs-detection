#!/usr/bin/env python
# coding=utf-8
# download repackaging pairs

import os
#import sys

sourceFile="/home/chicho/workspace/repackaged/repackaging_pairs.txt"

orignalDir="/home/chicho/workspace/repackaged/pairs/original/"

repackagedDir="/home/chicho/workspace/repackaged/pairs/repackaging/"

orignalList=os.listdir(orignalDir)

repackagedList={}

APIKEY="a52054307648be3c6b753eb55c093f4c2fa4b03e452f8ed245db653fee146cdd"

f=open(sourceFile)



#sys.exit(0)

downloadcnt=len(orignalList)
print downloadcnt

i=0
j=0
for line in f.readlines():
    
    j = j + 1

    print "J is:{0}".format(j)

    line=line.replace("\n","")

    SHA256_ORIGINAL = line.split(",")[0]
    SHA256_REPACKAGE = line.split(",")[1]

    apkfile = SHA256_ORIGINAL+".apk"


    if apkfile in orignalList:
        print apkfile
        index=orignalList.index(apkfile)
        print index
        print "the apk is..."+orignalList[index]
       # print orignalList[i]
        print "The file exits!..."
        i = i + 1
        print "i is {0}".format(i)
        continue
    else:
        print "downlaod apk...."
        cmd='''curl -O --remote-header-name -G -d apikey={0} -d sha256={1} https://androzoo.uni.lu/api/download'''.format(APIKEY,SHA256_ORIGINAL)
        os.system(cmd)

    

    


f.close()
