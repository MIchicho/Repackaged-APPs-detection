#!/usr/bin/env python
# coding=utf-8

import os 
import networkx as nx
from networkx.algorithms import isomorphism
import time 


oriPath = "/home/chicho/workspace/repackaged/DNADroid/experiment/falsepositive/sig/"

origraph = "/home/chicho/workspace/repackaged/DNADroid/experiment/falsepositive/graph"

handledResult = "/home/chicho/workspace/repackaged/DNADroid/experiment/falsepositive/similarScore.csv"

handledList = []

simf = open(handledResult)

for line in simf.readlines():
    line = line.replace("\n","")
    segs = line.split(",")
    newline = segs[0] + "," + segs[1]
    if newline not in handledList:
        handledList.append(newline)

simf.close()

if not os.path.exists(origraph):
    os.makedirs(origraph)


def createGraph(lines):

    GNameList = []
    GL = []
    
    for line in lines:

        if ":" and ";" in line:
            line = line.replace("\n","")

            segs = line.split(";")

            graphName = segs[0] 
        
            GNameList.append(graphName)
            
            G = nx.DiGraph()

            for i in range(2,len(segs)):

                if "," not in segs[i] and ":" in segs[i]:
                    edges = segs[i].split(":")

                    G.add_edge(int(edges[0]),int(edges[1]))


                if ":" in segs[i] and "," in segs[i]:
                    items = segs[i].split(":")        # 0:1,2 

                    edges = items[1].split(",")

                    for index in range(len(edges)):

                        G.add_edge(int(items[0]),int(edges[index]))

            GL.append(G)


    return (GNameList,GL)
            

# invoke last invoke 
def parseSig(oriPath):
   
#    i = 0
    apkList = os.listdir(oriPath)

    for i in range(len(apkList)):

        apkA = apkList[i]

        apkAPath = os.path.join(oriPath,apkA)

        for j in range(i+1,len(apkList)):

            apkB = apkList[j]

            apkBPath = os.path.join(oriPath,apkB)

            apkAname = apkA.split(".")[0]
            apkBname = apkB.split(".")[0]

            newline = apkAname + "," + apkBname 

            if newline in handledList:
                print newline + " has handled... ..."
                
                continue

            if not newline in handledList:
                handledList.append(newline)
                print "***************************"
                print "we are handled {0} ".format(newline)


            #*****************************************
            af = open(apkAPath)
            bf = open(apkBPath)

            afLines = af.readlines()
            bfLines = bf.readlines()
    
            oriGNameList,OGL = createGraph(afLines)
            repGNameList,RGL = createGraph(bfLines)

            
            if len(OGL)==0 or len(RGL)==0:
                print "we cannot get any node ... ..."
                continue

            tips = "the number of Graphs in original {0}".format(len(OGL))
            print tips 

            tips = "the number of Graph in repackaged {0}".format(len(RGL))
            print tips 
        
            mCnt = 0
            start1 = time.time()

            for GName in oriGNameList:

                if GName in repGNameList:
                   # print GName 
                    Gindex = oriGNameList.index(GName)
                    Tindex = repGNameList.index(GName)

                    G = OGL[Gindex]
                    T = RGL[Tindex]

                    GM = isomorphism.DiGraphMatcher(G,T)

                    if GM.subgraph_is_isomorphic():
                    #    print GM.mapping
                        mCnt += 1

            if len(oriGNameList):
                SimA_b = mCnt*1.0/len(oriGNameList)
                print SimA_b
            else:
                SimA_b =0
        
            end1 = time.time()

            elpase1 = end1-start1

            if elpase1>1200:
                continue 


            start2 = time.time()
            mCnt = 0
            for TName in repGNameList:

                if TName in oriGNameList:
                    Tindex = repGNameList.index(TName)
                    Gindex = oriGNameList.index(TName)

                    G = OGL[Gindex]
                    T = RGL[Tindex]

                    GM = isomorphism.DiGraphMatcher(T,G)

                    if GM.subgraph_is_isomorphic():
                       # print GM.mapping
                        mCnt += 1

            if len(repGNameList)!=0:
                SimB_a = mCnt*1.0/len(repGNameList)
                print SimB_a

            else:
                SimB_a = 0

            end2 = time.time()
            elpase2 = end2 - start2

            if elpase2>1200:
                continue

            # ***********************************

            cmd = "echo '{0}','{1}',{2},{3} >>{4}".format(apkA.split(".")[0],apkB.split(".")[0],SimA_b,SimB_a,"similarScore.csv")
            os.system(cmd)

            cmd = "echo {0} >> {1}".format(SimA_b,"ori_repSimilarValue4.csv")
    #        os.system(cmd)
            cmd = "echo {0} >> {1}".format(SimB_a,"rep_oriSimilarValue4.csv")
   #         os.system(cmd)

            cmd1 = "echo {0},{1},{2},{3} >> {4}".format(apkA.split(".")[0],apkB.split(".")[0],elpase1,elpase2,"runningtime.txt")
            os.system(cmd1)

            cmd2 = "echo {0} >> {1}".format(elpase1,"orirunningTime4.csv")
 #           os.system(cmd2)

            cmd3 = "echo {0} >>{1}".format(elpase2,"reprunningTime4.csv")
#            os.system(cmd3)

            af.close()
            bf.close()




        


parseSig(oriPath)


print "all work is done!"




