#!/usr/bin/env python
# coding=utf-8

import os
import math
from numpy import array
import numpy as np
import pylab as pl

simPath = "/home/chicho/workspace/repackaged/DNADroid/filter/similarScore.csv"

f = open(simPath)

def get_data(lines):
    
    minArry = []
    maxArry = []

    for line in lines:
        line = line.replace("\n","")

        segs = line.split(",")

        sim1 = float(segs[2])

        sim2 = float(segs[3])

        minValue = min(sim1,sim2)

        minArry.append(minValue)

        maxValue = max(sim1,sim2)

        maxArry.append(maxValue)


    minList = array(minArry)
    maxList = array(maxArry)

    return (minList,maxList)


lenths1,lenths2 = get_data(f.readlines())

def draw_hist2(lenths1,lenths2):
    data1 = lenths1
    data2 = lenths2

#    bins = np.linspace(min(data),max(data),50)
    bins = np.linspace(0,1,10)

    fig,(ax0,ax1)=pl.subplots(ncols=2,figsize=(14,6))

    ax0.hist(data1,bins,facecolor='g')

    ax0.set_title('# of app pairs whose smaller\n Similarity score is in range')


    ax1.hist(data2,bins)

    ax1.set_title('# of app pairs whose larger\n Similarity score is in range')

    pl.xlabel('Similarity Value Range(%)')


    pl.show()



draw_hist2(lenths1,lenths2)
