mvn clean compile assembly:single
